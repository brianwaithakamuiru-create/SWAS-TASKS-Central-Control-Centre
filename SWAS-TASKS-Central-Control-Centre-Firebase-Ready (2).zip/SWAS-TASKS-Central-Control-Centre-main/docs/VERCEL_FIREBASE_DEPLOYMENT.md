# SWAS TASKS Central Control Centre — Vercel + Firebase deployment

This source is configured for Firebase project **swas-tasks-control-centre** and the Firestore **(default)** database. Keep secrets out of the source ZIP and Git.

## 1. Firebase Console checklist

1. Open Firebase project `swas-tasks-control-centre`.
2. Authentication → Sign-in method: enable **Google** and **Email/Password**.
3. Authentication → Settings → Authorized domains: add the Vercel production domain and any Preview domain you intend to use for testing.
4. Firestore Database: make sure the **(default)** database exists.
5. The first Super Admin must sign in using the verified email configured as `BOOTSTRAP_SUPER_ADMIN_EMAIL` (`brianwaithakamiru@gmail.com`). The API provisions the `admin_users/{Firebase UID}` record after successful verified authentication. Do not manually change this record's role/status unless you know the impact.


## 2. Deploy Firestore rules and indexes

From the project folder with Firebase CLI installed and logged in:

```bash
firebase deploy --only firestore:rules,firestore:indexes --project swas-tasks-control-centre
```

Review `firestore.rules` before deploying. These rules target the application's `admin_users` collection and its RBAC roles, not the separate `admins` collection from an earlier setup.

## 3. Vercel

The repository has a root `server.ts` Express Node server. Vercel supports zero-configuration Node server deployments when it detects `server.ts`; the app's `npm run build` script builds the Vite client bundle served by the production Express server.


In Vercel, import the GitHub repository and use the repository root as the project root. Set the build command to:


```bash
npm run build
```

Use Node.js 22 or a newer supported version. After deployment, check the Vercel Functions/runtime logs for startup errors and visit `/api/v1/platform/status` and `/api/docs`.

## 4. Environment variables (Vercel → Settings → Environment Variables)

Set these server-side variables for Production and Preview as appropriate:

- `NODE_ENV` = `production`
- `APP_URL` = your deployed Control Centre URL (e.g. `https://your-control-centre.vercel.app`)
- `BOOTSTRAP_SUPER_ADMIN_EMAIL` = `brianwaithakamiru@gmail.com`
- `OFFICIAL_PLATFORM_EMAIL` = `swastaskorg@gmail.com`
- `EMAIL_SENDER_NAME` = `SWAS TASKS`
- `EMAIL_REPLY_TO` = `swastaskorg@gmail.com`
- `API_KEY_HMAC_SECRET` = generate a unique secret using `openssl rand -hex 32`
- `INVITATION_SIGNING_SECRET` = generate a different unique secret using `openssl rand -hex 32`

Set `PUBLIC_WEBSITE_URL` and `ALLOWED_ORIGINS` to the public website origin when connecting the separate public SWAS TASKS site. Do not include trailing paths in the origin. If only the Control Centre is being tested, these can remain unset.

Email delivery, SMS, and M-Pesa remain disabled until their provider credentials are configured. Never place provider passwords, service-account keys, or private secrets in `firebase-applet-config.json` or any `VITE_*` variable.


## 5. Storage

Firebase Storage was intentionally not configured in this project yet. Upload/branding features that depend on Storage will require enabling Storage in Firebase and publishing Storage rules separately.


## 6. First login smoke test

- Open the deployed URL and sign in with the verified Super Admin Google account.
- Confirm the server provisions `admin_users/{UID}` with active `SUPER_ADMIN` access.
- Confirm the dashboard loads and Firestore data listeners do not show permission errors.
- Test a non-destructive read first, then create a test department record if needed; remove test records after.
- Check `/api/v1/platform/status` and `/api/docs`.
- Do not test invitation/email delivery until an email provider is configured.
